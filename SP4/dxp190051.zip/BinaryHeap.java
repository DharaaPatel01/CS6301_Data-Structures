// Starter code for SP4

/**
 * Program implements a Heap Sort
 * It consists of various methods, the main methods being: add(), remove(), peek(), poll(), perlocateUp() and perlocateDown()
 * @author Andres Daniel Uriegas(adu170030)
 * @author Dhara Patel(dxp190051)
 * @param
 * */
package dxp190051;

import java.util.*;

public class BinaryHeap<T extends Comparable<? super T>> {
    Comparable[] pq;
    int size;
    int maxHeapCap = 0;
    boolean isResized = false;

    // Constructor for building an empty priority queue using natural ordering of T
    /**
     * Constructor of BinaryHeap
     * @param maxCapacity: max size of the heap
     * @return null
     * */
    public BinaryHeap(int maxCapacity) {
        pq = new Comparable[maxCapacity];
        size = 0;
        this.maxHeapCap = maxCapacity;
        isResized = false;
    }

    // add method: resize pq if needed
    /**
     * Method: add()
     * Resizes the queue if needed, then Adds an element to the queue and returns TRUE after element is added.
     * @param x: Element to be added
     * @return: boolean
     * */
    public boolean add(T x) {
        if(size == maxHeapCap){
            resize();
        }
        move(size,x);
        percolateUp(size);
        size += 1;
        return true;
    }

    /**
     * Method: offer()
     * Calls add method. Return false if element is not added else return true
     * @param x: Element to be added
     * @return: boolean
     * */
    public boolean offer(T x) { return add(x); }

    // throw exception if pq is empty
    /**
     * Method: remove()
     * Calls poll() method, save and return result.
     * @param: null
     * @return: throw exception(if the queue is empty) OR result from the poll() method.
     * */
    public T remove() throws NoSuchElementException {
        T result = poll();
        if(result == null) {
            throw new NoSuchElementException("Priority queue is empty");
        } else {
            return result;
        }
    }

    // return null if pq is empty
    /**
     * Method: poll()
     * Removes and returns element with the highest priority(minimum element)
     * @param: null
     * @return: element from top of pq[] OR null
     * */
    public T poll() {
        if (isEmpty()) {
            return null;
        }

        T minVal = min();
        move(0,pq[size-1]);
        move(size-1, null);
        size -= 1;
        percolateDown(0);
        return minVal;
    }

    /**
     * Method: min()
     * Calls peek() method
     * @param: null
     * @return: return the result of peek() method
     * */
    public T min() { 
	    return peek();
    }

    // return null if pq is empty
    /**
     * Method: peek()
     * Returns element with the highest priority(minimum element)
     * @param: null
     * @return: element from top of pq[] OR null
     * */
    public T peek() {
        if (isEmpty())
            return null;

        return (T) pq[0];
    }

    /**
     * Method: parent()
     * Returns parent of the node at int i
     * @param: Integer i; child node
     * @return: int (parent of the element i)
     * */
    int parent(int i) {
	    return (i-1)/2;
    }

    /**
     * Method: leftChild()
     * Returns left child of the node
     * @param: Integer i; parent node
     * @return: int (left child of the element i)
     * */
    int leftChild(int i) {
	    return 2*i + 1;
    }

    /** pq[index] may violate heap order with parent */
    /**
     * Method: percolateUp()
     * Moves elements based on the priority when adding a new element
     * @param: Integer index; position in the queue from where we need to percolate up
     * @return: null
     * */
    void percolateUp(int index) {
        Comparable tmp = pq[index];
        int parent = parent(index);

        while (index > 0 && compare(pq[index], pq[parent]) < 0) {
            move(index, pq[parent(index)]);
            move(parent(index), tmp);
            index = parent;
            parent = parent(index);
        }
    }

    /**
     * Method: getSmaller()
     * Returns the smaller child of the two children(left, right)
     * @param: Integer parent; parent node
     * @param: Integer n; max size of the heap
     * @return: element from queue (smaller child)
     * */
    public int getSmaller(int parent, int n) {
        int sc = leftChild(parent) + 1; //Assigning right child
        if ((sc >= n) || (compare(pq[sc - 1], pq[sc]) < 0))
            sc = sc - 1;
        return sc;
    }

    /** pq[index] may violate heap order with children */
    /**
     * Method: percolateDown()
     * Moves elements based on the priority
     * @param: Integer index; position from where we need to percolate down
     * @return: null
     * */
    void percolateDown(int index) {
        if (size > 0) {
            Comparable tmp = pq[index];
            int sChild = getSmaller(index, size);

            while ( sChild < size && compare(pq[index], pq[sChild]) > 0) {
                move(index, pq[sChild]);
                move(sChild, tmp);
                index = sChild;
                sChild = getSmaller(index, size);
            }
        }
        return;
    }

	/** use this whenever an element moved/stored in heap. Will be overridden by IndexedHeap */
    /**
     * Method: move()
     * Moves element x to the desired position(dest) in queue
     * @param: Integer dest,  Comparable x
     * @return: null
     * */
    void move(int dest, Comparable x) {
	    pq[dest] = x;
    }

    /**
     * Method: compare()
     * Compares two elements
     * @param: Comparable a, Comparable b
     * @return: Returns a negative integer, zero, or a positive integer as this object is less than, equal to, or greater than the specified object.
     * */
    int compare(Comparable a, Comparable b) {
	    return ((T) a).compareTo((T) b);
    }

    /** Create a heap.  Precondition: none. */
    /**
     * Method: buildHeap()
     * Builds heap from an array
     * @param: An array of type T
     * @return: null
     * */
    void buildHeap(T[] newPQ) {
        System.arraycopy(newPQ,0,pq,0,size);
        for(int i=parent(size-1); i>=0; i--) {
            percolateDown(i);
        }
    }

    /**
     * Method: isEmpty()
     * Checks if the queue is empty
     * @param: null
     * @return: Boolean value, True or False
     * */
    public boolean isEmpty() {
	    return size() == 0;
    }

    /**
     * Method: size()
     * Returns size of the queue
     * @param: null
     * @return: Integer (size of the queue)
     * */
    public int size() {
	    return size;
    }

    // Resize array to double the current size
    /**
     * Method: resize()
     * Resizes the queue
     * @param: null
     * @return: null
     * */
    void resize() {
        Comparable[] pqNew = new Comparable[maxHeapCap];
        System.arraycopy(pq,0 , pqNew ,0,size());
        pq = new Comparable[maxHeapCap*2];
        System.arraycopy(pqNew,0 , pq ,0,pqNew.length);
    }
    
    public interface Index {
        public void putIndex(int index);
        public int getIndex();
    }
	
	// IndexedHeap is useful to implement algorithms, such as Kruskal's MST, that requires
	// decreseKey() operation. You can impelement this now or later when you implement MST algorithms
    public static class IndexedHeap<T extends Index & Comparable<? super T>> extends BinaryHeap<T> {
        /** Build a priority queue with a given array */
        IndexedHeap(int capacity) {
            super(capacity);
		}

        /** restore heap order property after the priority of x has decreased */
        void decreaseKey(T x) {
        }

	@Override
        void move(int i, Comparable x) {
            super.move(i, x);
        }
    }

    public static void main(String[] args) {
        Integer[] arr = {0,9,7,5,3,1,8,6,4,2};
        BinaryHeap<Integer> h = new BinaryHeap(arr.length);

        System.out.print("Before:");
        for(Integer x: arr) {
            h.offer(x);
            System.out.print(" " + x);
        }
        System.out.println();

        for(int i=0; i<arr.length; i++) {
            arr[i] = h.poll();
        }

        System.out.print("After :");
        for(Integer x: arr) {
            System.out.print(" " + x);
        }
        System.out.println();
    }
}
