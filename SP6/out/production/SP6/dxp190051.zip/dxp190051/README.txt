Team Members:
Andres Daniel Uriegas(adu170030)
Dhara Patel(dxp190051)

Prerequisites

Before you continue, ensure you have met the following requirements:

* You have a IDE for Java.
* You are using JDK 15.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

BFSOddCycle class implements a BFS to find the odd length cycle in the graph
The methods used are:
a. oddCycle() - Finds odd length cycle in the graph and returns the cycle if it exists otherwise returns null
b. printOddCycle() - Prints the odd length cycle if graph is non-bipartite otherwise prints that the graph is partite.
